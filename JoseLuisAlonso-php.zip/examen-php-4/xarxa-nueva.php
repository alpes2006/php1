<?php require("php/xarxa-validacion-menus.php"); ?>

<!DOCTYPE html>
<html>
<head>
   <title>Menu Alta  (Examen) </title>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
   <link href="css\css-xarxa-php.css" rel="stylesheet" type="text/css"/>
   <link href="css\css-menu.css" rel="stylesheet" type="text/css"/>  
</head>
<body>
<!-- Validaciones de los campos -->
<?php

$titulo    = $descripcion = $nombre = "";
$tituloErr = $descripcionErr = $ficheroErr = "";

if (isset($_REQUEST["enviar-alta"])){

/* Quita espacios, quita barras. */       
     function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        return $data;
     }

  //Valida Titulo. Mas de 10 caracteres
  if (empty($_POST["titulo"])){
    $tituloErr=("Titulo obligatorio");
  }else{
    $titulo_long=strlen($_POST["titulo"]);
    if ($titulo_long>10){
       $titulo=($_POST["titulo"]);
       $tituloErr=(" "); 
    }else{
       $tituloErr=("Título tiene que tener mas de 10 caracteres.");
    }
  }
 
  //Valida Descripcion menos de 500 caracteres.
  if (empty($_POST["descripcion"])){
    $descripcionErr=("Descripcion obligatoria");
  }else{
    $descripcion_long=strlen($_POST["descripcion"]);
    if ($descripcion_long<500){
       $descripcion=$_POST["descripcion"];
       $descripcionErr=(" "); 
    }else{
       $descripcionErr=("NO puede ser mayor de 500 caracteres.");
    }
  }

//ejemplo 2:
    $nombre=$_FILES['fichero1']['name'];
    $guardado=$_FILES['fichero1']['tmp_name'];
    if (!file_exists('Ficheros Subidos')){
      mkdir('Ficheros Subidos',0777,true);
      if(file_exists('Ficheros Subidos')){
        if(move_uploaded_file($guardado,'Ficheros Subidos/'.$nombre)){
          $ficheroErr=('Fichero subido con exito');
        }else{
          $ficheroErr=('Fichero no se pudo subir');
        }
      }
    }else{
      if(move_uploaded_file($guardado,'Ficheros Subidos/'.$nombre)){
        $ficheroErr=('Fichero subido con exito');
      }else{
        $ficheroErr=('Fichero no se pudo subir');
      }
    }

}
?>

<!-- Menu principal -->
<div class="menu-principal">
    <nav class="navbar navbar-inverse">
     <div class="container-fluid">
       <div class="navbar-header">
         <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
         </button>
         <scan id="rdr" class="navbar-brand">RDR</scan>
       </div>
       <div class="collapse navbar-collapse" id="myNavbar">
         <ul class="nav navbar-nav">
           <li><a href="xarxa-inicio.php">Inicio</a></li>
           <li class="active"><a href="xarxa-nueva.php">Alta</a></li>
           <li><a href="xarxa-consulta.php">Consulta</a></li>
         </ul>
         <ul class="nav navbar-nav navbar-right">
           <li><a href="xarxa-nueva.php?logout" id="logout"><span class="glyphicon glyphicon-lock"></span>logout</a></li>           
         </ul>

       </div>
     </div>
    </nav> 
</div>
<header id="cabecera">
    <h1>Red de Ranas</h1>
    <span #class="saludos">Usuario: <?php require("php/xarxa-nombre.php");?></span>
</header>
<div id="contenidos-alta">
  <div class="texto1">
    <h3>Nueva Publicacion</h3>
    <!-- Pagina publica de entrada usuario y contraseña -->   
    <fieldset>
       <legend>Alta de Publicacion</legend>
       <form method="post" enctype="multipart/form-data"> 
          <p><label>Titulo: <input type="text" name="titulo" value="<?php echo "$titulo" ?>"><br/></label></p> 
             <span class="error"><?php print($tituloErr);?></span>
          <p><label>Descripcion:<br/><textarea name="descripcion" rows="10" colss="50"><?php echo $descripcion ?></textarea></label></p>
             <span class="error"><?php print($descripcionErr);?></span>
<!-- NOTA PARA EL PROFESOR: A la hora de subir el fichero en casa me daba problemas y al ejecutarlo 
en la clase, funciona correctamente. 
Creo que puede ser que en casa uso Linux y en clase Windows. -->             
          <input type="hidden"> 
          <p id="f1chero">Subir Imagen: <input type="file" name="fichero1" id="fichero1"/><span class="error"><?php print($ficheroErr);?></span></p>
          <br/><input type="submit" name="enviar-alta" value="Enviar"> 
       </form> 
    </fieldset> 
  </div>
</div>
<?php
if (isset($_REQUEST["enviar-alta"])){
    $nombre_completo="Ficheros Subidos/".$nombre;
?>    
    <!-- publicacion -->
    <div class="publicacion-mostrar">
      <h3 class="titulo-mostrar"><?php echo $titulo ?></h3>
      <div class="imagen-mostrar">
         <?php echo "<img src=\"$nombre_completo\">"; ?>
      </div>
      <article><?php echo $descripcion ?></article>
    </div>
<?php 
}
?>
<!-- Pie de pagina, nombre, direccion y mail. (Ddatos personales) -->
<?php require("php/pie_de_pagina.php"); ?>


</body>
</html>