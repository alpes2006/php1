<?php 
require("php/xarxa-validacion-menus.php");
?>

<!DOCTYPE html>
<html>
<head>
  <title>Menu-consulta</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link href="css\css-xarxa-php.css" rel="stylesheet" type="text/css"/>
  <link href="css\css-menu.css" rel="stylesheet" type="text/css"/>  
</head>
<body>
<!-- Menu principal -->
<div class="menu-principal">
    <nav class="navbar navbar-inverse">
     <div class="container-fluid">
       <div class="navbar-header">
         <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
           <span class="icon-bar"></span>
         </button>
         <scan id="rdr" class="navbar-brand">RDR</scan>
       </div>
       <div class="collapse navbar-collapse" id="myNavbar">
         <ul class="nav navbar-nav">
           <li><a href="xarxa-inicio.php">Inicio</a></li>
           <li><a href="xarxa-nueva.php">Alta</a></li>
           <li class="active"><a href="xarxa-consulta.php">Consulta</a></li>
         </ul>
         <ul class="nav navbar-nav navbar-right">
           <li><a href="xarxa-consulta.php?logout"><span class="glyphicon glyphicon-lock"></span>logout</a></li>           
         </ul>
       </div>
     </div>
    </nav> 
</div>

<header id="cabecera">
  <h1>Red de Ranas</h1> 
  <span>Usuario: <?php require("php/xarxa-nombre.php");?></span>
</header>
<clear>
<!-- Todas las publicaciones -->
<div id="contenidos-consulta">
   <h1>Ranas</h1>
<!-- publicacion-1 -->
   <div class="publicacion">  
     <h3 class="titulo">Rana de Color Azul</h3>
     <div class="imagen-publicacion">
        <img src="img/1-rana-azul.png" class="img-rounded" alt="1-rana-azul.png"/> 
     </div>
     <article> Las ranas de color azul viven en america.
        Las ranas de color azul viven en america. Las ranas de color azul viven en america.
     </article>
   </div>
   <div class="like"><p><label>like: <input type="text" class="like"></label></p> </div>
   <div class="comentario"><p><label>Comentario: <input type="text" class="cometnario"></label></p> </div>
<!-- publicacion-2 -->
   <div class="publicacion">
     <h3 class="titulo">Rana Multicolor</h3>
     <div class="imagen-publicacion">
       <img src="img/2-rana-arcoiris.jpg" class="img-rounded" alt="2-rana-arcoriris.jpg"/>
     </div>
     <article>
       Las ranas multicolor viven en africa. Las ranas multicolor viven en africa. 
       Las ranas multicolor viven en africa. Las ranas multicolor viven en africa. 
       Las ranas multicolor viven en africa. Las ranas multicolor viven en africa.
       Las ranas multicolor viven en africa. Las ranas multicolor viven en africa.
     </article>         
   </div>
   <div class="like"><p><label>like: <input type="text" class="like"></label></p> </div>
   <div class="comentario"><p><label>Comentario: <input type="text" class="comentario"></label></p> </div>
<!-- publicacion-3 -->
   <div class="publicacion">
     <h3 class="titulo">Rana de Color Rosa</h3>
     <div class="imagen-publicacion">
       <img src="img/3-rana-rosa.jpg" class="img-rounded" alt="3-rana-rosa.jpg"/>
     </div>
     <article>
       Las ranas de color rosa viven en sitges. Las ranas de color rosa viven en sitges.
       Las ranas de color rosa viven en sitges. Las ranas de color rosa viven en sitges.
     </article>
   </div>
   <div class="like"><p><label>like: <input type="text" class="like"></label></p> </div>
   <div class="comentario"><p><label>Comentario: <input type="text" class="comentario"></label></p> </div>
</div>
<?php require("php/pie_de_pagina.php"); ?>

</body>
</html>
