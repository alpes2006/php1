<!DOCTYPE html>
<html lang="es">
<head>
  <title>Examen - php - red-ranas </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link href="css\css-xarxa-php.css" rel="stylesheet" type="text/css"/>
<!--  <link href="..\css\menu.css" rel="stylesheet" type="text/css"/>  -->
</head>
<body>


<?php
$i = 0;
$nombre = $apellidos = $fnac = $fecha_act = $fecha_actual = $Email = $usuario = $pwd1 = $pwd2 = "";   
$nombreErr = $apellidosErr = $fnacErr = $EmailErr = $usuarioErr = $pwd1Err[] = $pwd2Err = "";

if (isset($_REQUEST["enviar-alta"])){
    
// Validacion de campos vacio
// Quita espacios, quita barras
   function test_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      return $data;
   }

// Campo nombre: Valida que no esté vacio.
   if (empty($_POST["nombre"])){
     $nombreErr=("nombre obligatorio");
   }else{
     $nombre=test_input($_POST["nombre"]); 
     if (!preg_match("/^[a-zA-Z]*$/",$nombre)){
        $nombreErr = "Introduce el nombre correctamente."; 
     }
   }   

 // Campo Apellido: Valida que no este vacio.
 if (empty($_POST["apellidos"])){
   $apellidosErr=("Apellido obligatorio");
}else{
   $apellidos=test_input($_POST["apellidos"]); 
   if (!preg_match("/^[a-zA-Z]*$/",$apellidos)){
      $apellidosErr = "Introduce el apellido correctamente."; 
   }
}

// Campo Fecha de nacimiento: Valida que no este vacio.
if (empty($_POST["fnac"])){
   $fnacErr=("Fecha de nacimiento obligatoria");
}else{
   $fnac=test_input($_POST["fnac"]);
   $fecha_18=date("Y/m/d",strtotime($fecha_actual."- 18 year"));
   echo("fnac:".$fnac);
   echo("fecha_18: ".$fecha_18);   
   if ($fnac > $fecha_18){
      $fnacErr = "Tienes que ser mayor de edad."; 
   }
}

// Campo email.
    if (empty($_POST["email"])){
      $EmailErr=("Email obligatorio");
   }else{
      $Email=test_input($_POST["email"]);  
      if (!filter_var($Email, FILTER_VALIDATE_EMAIL)){
         $EmailErr=("Formato del Email inválido."); 
      }
   }


// Campo EMail: Valida que no este vacio.
if (empty($_POST["email"])){
   $EmailErr=("email obligatorio");
}else{
   $Email=test_input($_POST["email"]); 
   if (!preg_match("/^[a-zA-Z]*$/",$f)){
      $EmailErr = "Email: No es valido."; 
   }
}

    // Campo usuario.
    if (empty($_POST["usuario1"])){
       $usuarioErr=("Usuario obligatorio");
    }else{
       $usuario=test_input($_POST["usuario1"]); 
       if (!preg_match("/^[a-zA-Z]*$/",$usuario)){
          $usuarioErr = "Usuario: No se permiten caracteres especiales."; 
       }
    }
    
    // Contraseña 1.
    $pwd1=test_input($_POST["pwd1"]);     
    if (empty($pwd1)){
       $pwd1Err[$i]=("Campo contraseña obligatorio");
       $i=$i+1;
    }else{
    //Entre 6 Y 8 caracteres
        $pwd1_long=strlen($pwd1);
        if (($pwd1_long>5) && ($pwd1_long<9)){
           $pwd1Err[$i]=(" "); 
        }else{
           $pwd1Err[$i]=("El campo tiene que tener entre 6 y 8 caracteres.");
           $i=$i+1;           
        }
    //Valida mayusculas 
        if (preg_match_all("/[A-Z]/", $pwd1)==0){
           $pwd1Err[$i]=("Añade un caracter en mayuscula.");
           $i=$i+1;      
        }
    //Valida minusculas
        if (preg_match("/[a-z]/", $pwd1)==0){
           $pwd1Err[$i]=("Añade un caracter en minuscula.");
           $i=$i+1;           
        }
    //Valida numeros
        if (preg_match_all("/[0-9]/", $pwd1)==0){
           $pwd1Err[$i]=("Tiene que tener almenos un numero.");
           $i=$i+1;           
        }
    //Valida caracteres especiales
        if (preg_match_all("/[!$%&?¿¡]/", $pwd1)==0){
           $pwd1Err[$i]=("Añade un caracter especial [!, $, %, &, ?, ¿, ¡].");
           $i=$i+1;           
        }
    }
    //Valida contraseña Contraseña2 y compara con Contraseña1
    $pwd2=test_input($_POST["pwd2"]);    
    if (empty($pwd2)){
        $pwd2Err=("La contraseña2 de validacion esta vacia.");
    }elseif ($pwd1==$pwd2){
            $pwd2Err=(" ");
         }else{
            $pwd2Err=("Valida que las contraseñas coincidan.");
    }
}
?>
<header id="cabecera">
    <h1>Red de Ranas</h1>
</header>
<div id="contenidos-xarxa">
   <div class="texto-xarxa">
   <h3>Alta</h3>
<!-- Pagina publica de entrada usuario y contraseña -->   
     <form method="post">
     <fieldset>
     <legend>Datos Personales</legend>
       <p><label>Nombre: <input type="text" name="nombre" value="<?php echo $nombre ?>"><br/></label></p> 
       <span class="error"><?php print("<br/>".$nombreErr);?></span></p>       
       <p><label>Apellidos: <input type="text" name="apellidos" value="<?php echo $apellidos ?>"><br/></label></p>        
       <span class="error"><?php print("<br/>".$apellidosErr);?></span></p>              
       <p><label>Fecha de Nacimiento: <input type="date" name="fnac" value="<?php echo $fnac ?>"><br/></label></p>   
       <span class="error"><?php print("<br/>".$fnacErr);?></span></p>                                 
       <p><label>E-mail: <input type="text" name="email" value="<?php echo $Email ?>"><br/></label></p> 
       <span class="error"><?php print("<br/>".$EmailErr);?></span></p>       
     </fieldset>
     <fieldset>
     <legend>Alta de Usuario y validar contraseña</legend>
        <p><label>Usuario: <input type="text" name="usuario1" id="usuario1" value="<?php echo $usuario ?>"/><br/></label></p>
        <span class="error"><?php if ($i>0) {print("<br/>".$usuarioErr);}?></span></p>
        <p>Contraseña: <input type="password" name="pwd1" id="pwd1" value="<?php echo $pwd1 ?>"/>
        <span class="error">
            <?php     
                 for ($i=0; $i<(count($pwd1Err)); $i++){
                    echo("<br/>".$pwd1Err[$i]);
                 }
            ?>
        </span></p>
        <p>Repite Contraseña: <input type="password" name="pwd2" id="pwd2" value="<?php echo $pwd2 ?>"/>
        <span class="error"><?php print("<br>".$pwd2Err);?></span></p>
        <p><br/><a href="Examen-Xarxa-Social.php">Volver al Menu de login</a></p>
        <input type="submit" name="enviar-alta" value="Enviar"/>
     </fieldset>     
     </form>      
   </div>   
</div>

<div class="pie_de_pagina">
     <address>El gran mundo de los amfibios - C/Red de Ranas, 555 - RedDeRanas123@hotmail.com</address>
</div>

</body>
</html>