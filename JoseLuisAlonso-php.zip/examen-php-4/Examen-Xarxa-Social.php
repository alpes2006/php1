<?php 
session_start();

$error= " ";

//Si tenemos las cookis nomusuari y password activas va direcctamente al menu inicial.
if ((isset($_COOKIE["password"])) && (isset($_COOKIE["nomusuari"]))) {
   echo ("con logoff: no tiene que entrar");
  
   if (($_COOKIE["password"]=="700c8b805a3e2a265b01c77614cd8b21") && ($_COOKIE["nomusuari"]=="aaa")) { 
      header('Location:xarxa-inicio.php');   
   }else{ 
      $error="credenciales incorrectas"; 
   } 
}

/* Cuando damos al submit con los valores correctos: usuario: "aaa" y contraseña: "1234". Nos lleva a la
pagina privada inicial. */
if (isset($_REQUEST["submit"])){ 
    if (((($_REQUEST["username"]))=="aaa") &&
      (md5(sha1($_REQUEST["password"]))=="700c8b805a3e2a265b01c77614cd8b21")){ 
          $_SESSION["nom"]=$_REQUEST["username"]; 
          $_SESSION["password"]=md5(sha1($_REQUEST["password"]));
          if((isset($_REQUEST["recordar"])) && ($_REQUEST["recordar"]==true)){ 
               setcookie("nomusuari",$_REQUEST["username"],time()+365*24*60*60); 
               setcookie("password",$_SESSION["password"],time()+365*24*60*60); 
           } 
          header('Location:xarxa-inicio.php');           
      }else{ 
          $error="Usuario o contraseña incorrecta."; 
      } 
} 
?> 
<!DOCTYPE html>
<html lang="es">
<head>
  <title>Examen - php - red-ranas </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link href="css\css-xarxa-php.css" rel="stylesheet" type="text/css"/>
</head>
<body>

  <header id="cabecera">
    <h1>Red de Ranas</h1>
  </header>

<div id="contenidos-xarxa">

  <div class="texto-xarxa">

  <h3>Registro</h3>
<!-- Pagina publica de entrada usuario y contraseña -->   
   <fieldset>
     <legend>Usuario y contraseña</legend>
     <div class="error"><?=$error?></div> 
     <form  method="post"> 
       <p><label>Usuario: <input type="text" name="username"><br/></label></p> 
       <p><label>Contraseña: <input type="password" name="password" ><br/></label></p> 
       <p><label>Recordar <input type="checkbox" name="recordar"><br/></label></p>
       <p>Si quieres darte de alta <a href="xarxa-pwd-ex.php"> Pulsa aquí</a><br/></p>
       <input type="submit" name="submit" value="Enviar"> 
     </form> 
   </fieldset>     
  </div>   

</div>
<?php require("php/pie_de_pagina.php"); ?>
</body>
</html>