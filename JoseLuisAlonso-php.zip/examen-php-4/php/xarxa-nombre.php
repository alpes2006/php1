 <?php
        if (isset($_SESSION["nom"])){
          echo ($_SESSION["nom"]);
        }else{
          echo ($_COOKIE["nomusuari"]);
        }
  ?>