<?php
 
session_start();

if(isset($_REQUEST["logout"])){ 
    session_destroy();  
    setcookie("nomusuari",0,1); 
    setcookie("password",0,1); 
    header('Location:Examen-Xarxa-Social.php');                
} 

if (((isset($_SESSION["nom"]) && ($_SESSION["nom"]=="aaa")) &&
    (isset($_SESSION["password"]) && ($_SESSION["password"]=="700c8b805a3e2a265b01c77614cd8b21"))) ||    
    
    ((isset($_COOKIE["nomusuari"]) && ($_COOKIE["nomusuari"]=="aaa")) &&
      (isset($_COOKIE["password"]) && ($_COOKIE["password"]=="700c8b805a3e2a265b01c77614cd8b21")))){
  //Continua 
}else{ 
    header('Location:Examen-Xarxa-Social.php'); 
}
?>
